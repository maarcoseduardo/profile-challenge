/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.tsx"],
  theme: {
    // colors: {
    //   'pink-dark-300': '#9B39AE',
    //   'blue-dark-300': '#06ADE4',
    // },
    extend: {},
  },
  plugins: [],
}
