import { UsersList } from "../components/usersList";


export function Home() {
  return (
    <UsersList />
  )
}