import { Details } from "../components/details";

export function Profile() {

  return (
    <>
      <Details />
    </>
  )
}